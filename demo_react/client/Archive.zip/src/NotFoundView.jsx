import React, { Component } from 'react';

class NotFoundView extends Component {
    render(){
        return (<h1>Page not found</h1>);
    }
}

export default NotFoundView